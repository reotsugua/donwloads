<?php
echo '<html>
<head><title>P�gina Inicial - Numerador</title>';
echo '<meta http-equiv="content-type" content="text/html"; charset=iso-8859-1">';
echo '</head>';
echo '<body bgcolor="#ffffff" text="#000000" link="#333399" vlink="#cc0000" alink="#663399">';
//echo '<center><h1><font color="#0000ff">Numerador SJD</font></h1></center>';
echo '<center><h1>Numerador SJD</h1></center>';

echo '<form method="post" action="/joomla25/sjd/numerador/numerador.php">';
/* Fazendo a query SQL*/
include("conectar.php");
$sql = "SELECT * FROM TipoDoc order by documento";
$tabela = mysql_query($sql, $conexao) or die ("mysql_query: ".mysql_error());


echo '<table width="575" border="0" cellspacing="1" align="center"><tr>';
echo '<tr><td>Tipo de Documento: </td>';
echo '<td><select name="iddoc">';
//la�o while
echo '<option value="0">Selecione o tipo de documento';
while($linhas = mysql_fetch_array($tabela)){
//aqui vai aparecer sua tabela..
echo "<option value=".$linhas['iddoc'].">".$linhas['documento'];
};
echo '</select></td></tr>';

echo '<tr><td> Destino: </td>
<td><input type="text" name="destino" size="25" maxlength="100" value=""></td>
<td> Elaborador: </td>
<td><input type="text" name="elaborador" size="25" maxlength="50" value=""></td></tr>';
echo '<tr><td> Assunto: </td><td><input type="text" name="assunto" size="25" maxlength="50" value=""></td>
<td>Interessado: </td><td><input type="text" name="interessado" size="25" maxlength="50" value=""></td></tr>';
echo '<tr><td> Refer�ncia: </td><td><input type="text" name="referencia" size="25" maxlength="100" value=""></td>
<td></td><td></td></tr>';
echo '</table>';

echo '<hr>';
echo '<table width="575" border="0" cellspacing="1" align="center"><tr>';
echo '<td></td>';
echo '<td><center><input type="submit" name="Submit" value="Cadastrar"></center></td>';
echo '<td><a href="/joomla25/sjd/numerador/consnumer.php">Consulta Numeradores</a></td>';
echo '<td><a href="/joomla25/sjd/numerador/altnumer.php">Alterar Numeradores</a></td>';
echo '</tr></table>';
echo '</form>';
echo '<hr>';

$iddoc = $_POST['iddoc'];
//echo '<p>IDDOC:'.$iddoc.'</p>';

$destino = $_POST['destino'];
//echo '<p>Destino:'.$destino.'</p>';

$elaborador = $_POST['elaborador'];
//echo '<p>Elaborador:'.$elaborador.'</p>';

$assunto = $_POST['assunto'];
//echo '<p>Assunto:'.$assunto.'</p>';

$interessado = $_POST['interessado'];
//echo '<p>Interessado:'.$interessado.'</p>';

$referencia = $_POST['referencia'];
//echo '<p>Referencia:'.$referencia.'</p>';

/*Formata��o da data*/
$sql02 = "select version(), now()";
$tabela02 = mysql_query($sql02, $conexao) or die ("mysql_query: ".mysql_error());
$linhas02 = mysql_fetch_array($tabela02);
//$version = $linhas1['version()'];
//echo '<P> Version= '.$version.'</P>';
$now = $linhas02['now()'];
//echo '<p>Agora: '.$now.'</p>';
//// separar a hora da data
//$ftnow = explode(' ',$now);
//$ftdata = $ftnow[0];
//$fthora = $fvalor[1];
//$ftdata1 = explode('-',$ftdata);
//$ftano = $ftdata1[0];
//$ftmes = $ftdata1[1];
//$ftdia = $ftdata1[2];


//if ($iddoc == 0) {
//echo '<h1>Por favor, seu burro, selecione o tipo de documento!</h1>';
//}

if (empty ($destino)) {
echo '<p><b>Por favor, insira um destino!</b></p>';
}

if (empty ($elaborador)) {
echo '<p><b>Por favor, insira um elaborador!</b></p>';
}

if ((empty($destino)) || (empty($elaborador))) {
echo '<p><b>Error, n�o foi solicitado n�mero!</b></p>';
}else{

if ($iddoc == 1) {
$sql1 = "INSERT INTO NumCPR VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>CARTA PRECAT�RIA: </b>';
$sql2 = "select numCPR,destino,elaborador,assunto,interessado,referencia from NumCPR order by numcpr desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 2) {
$sql1 = "INSERT INTO NumCP VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>CERTID�O PUBLICIDADE: </b>';
$sql2 = "select numcp,destino,elaborador,assunto,interessado,referencia from NumCP order by numcp desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 3) {
$sql1 = "INSERT INTO NumCV VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>CONVITE: </b>';
$sql2 = "select numcv,destino,elaborador,assunto,interessado,referencia from NumCV order by numcv desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 4) {
$sql1 = "INSERT INTO NumDE VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>DESPACHO: </b>';
$sql2 = "select numde,destino,elaborador,assunto,interessado,referencia from NumDE order by numde desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 5) {
$sql1 = "INSERT INTO NumInf VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>INFORMA��O: </b>';
$sql2 = "select numinf,destino,elaborador,assunto,interessado,referencia from NumInf order by numinf desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 6) {
$sql1 = "INSERT INTO NumIT VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>INTIMA��O: </b>';
$sql2 = "select numit,destino,elaborador,assunto,interessado,referencia from NumIT order by numit desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 7) {
$sql1 = "INSERT INTO NumIP VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>INVESTIGA��O PRELIMINAR: </b>';
$sql2 = "select numip,destino,elaborador,assunto,interessado,referencia from NumIP order by numip desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 8) {
$sql1 = "INSERT INTO NumLD VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>LAUDA: </b>';
$sql2 = "select numld,destino,elaborador,assunto,interessado,referencia from NumLD order by numld desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 9) {
$sql1 = "INSERT INTO NumMm VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>MEMORANDO: </b>';
$sql2 = "select nummm,destino,elaborador,assunto,interessado,referencia from NumMm order by nummm desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}


if ($iddoc == 10) {
$sql1 = "INSERT INTO NumEM VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>MENSAGEM DE EMAIL: </b>';
$sql2 = "select numem,destino,elaborador,assunto,interessado,referencia from NumEM order by numem desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 11) {
$sql1 = "INSERT INTO NumFX VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>MENSAGEM DE FAX: </b>';
$sql2 = "select numfx,destino,elaborador,assunto,interessado,referencia from NumFX order by numfx desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 12) {
$sql1 = "INSERT INTO NumNBI VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>NOTA PARA BOLETIM INTERNO: </b>';
$sql2 = "select numnbi,destino,elaborador,assunto,interessado,referencia from NumNBI order by numnbi desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 13) {
$sql1 = "INSERT INTO NumOf VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>OF�CIO: </b>';
$sql2 = "select numof,destino,elaborador,assunto,interessado,referencia from NumOf order by numof desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 14) {
$sql1 = "INSERT INTO NumOS VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>ORDEM DE SERVI�O: </b>';
$sql2 = "select numos,destino,elaborador,assunto,interessado,referencia from NumOS order by numos desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 15) {
$sql1 = "INSERT INTO NumPT VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>PARTE: </b>';
$sql2 = "select numpt,destino,elaborador,assunto,interessado,referencia from NumPT order by numpt desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 16) {
$sql1 = "INSERT INTO NumPD VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>PROCEDIMENTO DISCIPLINAR: </b>';
$sql2 = "select numpd,destino,elaborador,assunto,interessado,referencia from NumPD order by numpd desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 17) {
$sql1 = "INSERT INTO NumRL VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>RELAT�RIO: </b>';
$sql2 = "select numrl,destino,elaborador,assunto,interessado,referencia from NumRL order by numrl desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 18) {
$sql1 = "INSERT INTO NumAt VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>ATESTADO: </b>';
$sql2 = "select numat,destino,elaborador,assunto,interessado,referencia from NumAt order by numat desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

if ($iddoc == 19) {
$sql1 = "INSERT INTO NumCt VALUES ('','$destino','$elaborador','$assunto','$interessado','$referencia','$now')";
//echo '<p>SQL1 = '.$sql1.'</p>';
$tabela = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());

echo '<b>CERTID�O: </b>';
$sql2 = "select numct,destino,elaborador,assunto,interessado,referencia from NumCt order by numct desc LIMIT 0,10";
$result2 = mysql_query($sql2) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";

}

}
?>