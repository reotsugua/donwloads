<?php
echo '<html>
<head><title>P�gina Inicial - Sys SJD</title>';
echo '<meta http-equiv="content-type" content="text/html"; charset=iso-8859-1">';
echo '</head>';
echo '<body bgcolor="#ffffff" text="#000000" link="#333399" vlink="#cc0000" alink="#663399">';

echo '<p><h1><center>Formul�rio de Altera��o do Numerador</center></h1></p>';

echo '<form method="post" action="/joomla25/sjd/numerador/altnumer.php">';
/* Fazendo a query SQL*/
include("conectar.php");
$sql = "SELECT * FROM TipoDoc order by documento";
$tabela = mysql_query($sql, $conexao) or die ("mysql_query: ".mysql_error());

echo '<table width="575" border="0" cellspacing="1" align="center"><tr>';
echo '<tr><td>Documento: </td>';
echo '<td><select name="iddoc">';
//la�o while
echo '<option value="0">Selecione o tipo de documento';
while($linhas = mysql_fetch_array($tabela)){
//aqui vai aparecer sua tabela..
echo "<option value=".$linhas['iddoc'].">".$linhas['documento'];
};
echo '</select></td>';

echo '<td> N�mero: </td>
<td><input type="text" name="numero" size="10" maxlength="10" value=""></td></tr>';

echo '</table>';

echo '<hr>';
echo '<table width="575" border="0" cellspacing="1" align="center"><tr>';
echo '<td><a href="/joomla25/sjd/numerador/numerador.php">Numerador SJD</a></td>';
echo '<td><center><input type="submit" name="Submit" value="Busca"></center></td>';
echo '</tr></table>';
echo '<hr>';

$iddoc = $_POST['iddoc'];
//echo '<p>IDDOC:'.$iddoc.'</p>';

$numero = $_POST['numero'];
//echo '<p>N�mero:'.$numero.'</p>';

if ($iddoc == 1) {
echo 'CARTA PRECAT�RIA N� '.$numero.'';
$sql1 = "select * from NumCPR where numcpr=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 2) {
echo 'CERTID�O DE PUBLICIDADE N� '.$numero.'';
$sql1 = "select * from NumCP where numcp=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 3) {
echo 'CONVITE N� '.$numero.'';
$sql1 = "select * from NumCV where numcv=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 4) {
echo 'DESPACHO N� '.$numero.'';
$sql1 = "select * from NumDE where numde=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 5) {
echo 'INFORMA��O N� '.$numero.'';
$sql1 = "select * from NumInf where numinf=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 6) {
echo 'INTIMA��O N� '.$numero.'';
$sql1 = "select * from NumIT where numit=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 7) {
echo 'INVESTIGA��O PRELIMINAR N� '.$numero.'';
$sql1 = "select * from NumIP where numip=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 8) {
echo 'LAUDA N� '.$numero.'';
$sql1 = "select * from NumLD where numld=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 9) {
echo 'MEMORANDO N� '.$numero.'';
$sql1 = "select * from NumMm where nummm=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 10) {
echo 'MENSAGEM DE EMAIL N� '.$numero.'';
$sql1 = "select * from NumEM where numem=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 11) {
echo 'MENSAGEM DE FAX N� '.$numero.'';
$sql1 = "select * from NumFX where numfx=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 12) {
echo 'NOTA PARA BOLETIM INTERNO N� '.$numero.'';
$sql1 = "select * from NumNBI where numnbi=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 13) {
echo 'OF�CIO N� '.$numero.'';
$sql1 = "select * from NumOf where numof=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 14) {
echo 'ORDEM DE SERVI�O N� '.$numero.'';
$sql1 = "select * from NumOS where numos=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 15) {
echo 'PARTE N� '.$numero.'';
$sql1 = "select * from NumPT where numpt=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 16) {
echo 'PROCEDIMENTO DISCIPLINAR N� '.$numero.'';
$sql1 = "select * from NumPD where numpd=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 17) {
echo 'RELAT�RIO N� '.$numero.'';
$sql1 = "select * from NumRL where numrl=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 18) {
echo 'ATESTADO N� '.$numero.'';
$sql1 = "select * from NumAt where numat=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

if ($iddoc == 19) {
echo 'CERTID�O N� '.$numero.'';
$sql1 = "select * from NumCt where numct=$numero";
$tabela1 = mysql_query($sql1, $conexao) or die ("mysql_query: ".mysql_error());
$line1 = mysql_fetch_array($tabela1);
}

echo '</form>';

echo '<form method="post" action="/joomla25/sjd/numerador/alt1numer.php">';
echo '<table width="575" border="0" cellspacing="1" align="center"><tr>';
echo '<tr><td>Destino: </td><td><INPUT type="text" name="destino1" size="25" maxlength="100" value="'.$line1["destino"].'"></td>';
echo '<td>Elaborador: </td><td><INPUT type="text" name="elaborador1" size="25" maxlength="50" value="'.$line1["elaborador"].'"></td></tr>';
echo '<tr><td>Assunto:</td><td><INPUT type="text" name="assunto1" size="25" maxlength="50" value="'.$line1["assunto"].'"></td><td>Interessado:</td><td><INPUT type="text" name="interessado1" size="25" maxlength="50" value="'.$line1["interessado"].'"></td></tr>';
echo '<tr><td>Refer�ncia: </td><td><INPUT type="text" name="referencia1" size="25" maxlength="100" value="'.$line1["referencia"].'"></td>';
echo '<td></td><td><center><input type="submit" name="Submit" value="Alterar"></center></td></tr>';
echo '</table>';
echo '<INPUT type="hidden" name="iddoc" size="25" maxlength="50" value="'.$iddoc.'">';
echo '<INPUT type="hidden" name="numero" size="25" maxlength="50" value="'.$numero.'">';
echo '</form>';


echo '</body></html>';
?>