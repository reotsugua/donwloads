<?php
//Conecto-me ao servidor MySQL


//Utilizado no CPA/M-4 - SJD
$conexao = mysql_connect("54.82.99.51", "root", "9aH&11a6");
//Verifico se a conex�o foi bem sucedida
if ($conexao == true) {
//Seleciono o database


$db = mysql_select_db("SJD");
//Verifico se houve erro ao selecionar o database
if ($db == false) {
//Imprimo a mensagem de erro
echo "Erro na sele��o do database: ".mysql_error();
}
}
else {
//Imprimo a mensagem de erro
echo "Erro na conex�o: ".mysql_error();
}
?>