<?php
echo '<html><head><title>P�gina Inicial - Sys SJD</title>';
echo '<meta http-equiv="content-type" content="text/html"; charset=iso-8859-1">';
echo '</head>';
echo '<body bgcolor="#ffffff" text="#000000" link="#333399" vlink="#cc0000" alink="#663399">';
echo '<center><h1>Numerador SJD</h1></center>';
echo '<p><center><a href="/joomla25/sjd/numerador/numerador.php">Numerador</a> - <a href="/joomla25/sjd/numerador/altnumer.php">Alterar Numerador</a></center></p>';
include("conectar.php");

echo '<form method="post" action="/joomla25/sjd/numerador/consnumer.php">';
$sql = "SELECT * FROM TipoDoc order by documento";
$tabela = mysql_query($sql, $conexao) or die ("mysql_query: ".mysql_error());

echo '<table width="575" border="0" cellspacing="1" align="center"><tr>';
echo '<tr><td>Tipo de Documento: </td>';
echo '<td><select name="iddoc">';
//la�o while
echo '<option value="0">Selecione o tipo de documento';
while($linhas = mysql_fetch_array($tabela)){
//aqui vai aparecer sua tabela..
echo "<option value=".$linhas['iddoc'].">".$linhas['documento'];
};
echo '</select></td><td><center><input type="submit" name="Submit" value="Enviar"></center></td></tr>';

$iddoc = $_POST['iddoc'];
//echo '<p>IDDOC:'.$iddoc.'</p>';

$sql01 = "SELECT documento FROM TipoDoc WHERE iddoc='$iddoc'";
//$consulta01 = mysql_query($sql01, $conexao) or die ("mysql_query: ".mysql_error());
$consulta01 = mysql_query($sql01, $conexao);
//echo '<p>CONSULTA01:'.$consulta01.'</p>';
$line01 = mysql_fetch_array($consulta01, MYSQL_ASSOC);
$documento = $line01[documento];

if (empty($iddoc)) {
   echo'<b>Selecione um tipo de Documento!</b>';
   
  }else{
  
if ($iddoc == 1) {
    $sql02 = "select numCPR,destino,elaborador,assunto,interessado,referencia from NumCPR";
}

if ($iddoc == 2) {
    $sql02 = "select numcp,destino,elaborador,assunto,interessado,referencia from NumCP";
}

if ($iddoc == 3) {
    $sql02 = "select numcv,destino,elaborador,assunto,interessado,referencia from NumCV";
}

if ($iddoc == 4) {
    $sql02 = "select numde,destino,elaborador,assunto,interessado,referencia from NumDE";
}

if ($iddoc == 5) {
    $sql02 = "select numinf,destino,elaborador,assunto,interessado,referencia from NumInf";
}

if ($iddoc == 6) {
    $sql02 = "select numit,destino,elaborador,assunto,interessado,referencia from NumIT";
}

if ($iddoc == 7) {
    $sql02 = "select numip,destino,elaborador,assunto,interessado,referencia from NumIP";
}

if ($iddoc == 8) {
    $sql02 = "select numld,destino,elaborador,assunto,interessado,referencia from NumLD";
}

if ($iddoc == 9) {
    $sql02 = "select nummm,destino,elaborador,assunto,interessado,referencia from NumMm";
}

if ($iddoc == 10) {
    $sql02 = "select numem,destino,elaborador,assunto,interessado,referencia from NumEM";
}

if ($iddoc == 11) {
    $sql02 = "select numfx,destino,elaborador,assunto,interessado,referencia from NumFX";
}
if ($iddoc == 12) {
    $sql02 = "select numnbi,destino,elaborador,assunto,interessado,referencia from NumNBI";
}

if ($iddoc == 13) {
    $sql02 = "select numof,destino,elaborador,assunto,interessado,referencia from NumOf";
}

if ($iddoc == 14) {
    $sql02 = "select numos,destino,elaborador,assunto,interessado,referencia from NumOS";
}

if ($iddoc == 15) {
    $sql02 = "select numpt,destino,elaborador,assunto,interessado,referencia from NumPT";
}

if ($iddoc == 16) {
    $sql02 = "select numpd,destino,elaborador,assunto,interessado,referencia from NumPD";
}

if ($iddoc == 17) {
    $sql02 = "select numrl,destino,elaborador,assunto,interessado,referencia from NumRL";
}

if ($iddoc == 18) {
    $sql02 = "select numat,destino,elaborador,assunto,interessado,referencia from NumAt";
}

if ($iddoc == 19) {
    $sql02 = "select numct,destino,elaborador,assunto,interessado,referencia from NumCt";
}

}

if (empty($iddoc)) {
      
  }else{
echo '<p><b>'.$documento.': </b></p>';

$result02 = mysql_query($sql02) or die("A query falhou: " . mysql_error());
    print "<table WIDTH=\"100%\" BORDER=\"1\">\n";
    print "\t<tr>\n";
    print "\t\t<td>N�mero</td>\n";
    print "\t\t<td>Destino</td>\n";
    print "\t\t<td>Elaborador</td>\n";
    print "\t\t<td>Assunto</td>\n";
    print "\t\t<td>Interessado</td>\n";
    print "\t\t<td>Refer�ncia</td>\n";
    print "\t</tr>\n";
    while ($line = mysql_fetch_array($result02, MYSQL_ASSOC)) {
        print "\t<tr>\n";
        foreach ($line as $col_value) {
            print "\t\t<td>$col_value</td>\n";
        }
        print "\t</tr>\n";
    }
    print "</table>\n";
    
}
    echo '</form>';

    echo '</table>';

echo '</body></html>';
?>