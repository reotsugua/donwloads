<?php
echo '<p><center><h1>Alterado com sucesso</h1></center></p>';
include("conectar.php");

$iddoc = $_POST['iddoc'];
//echo '<p>IDDOC:'.$iddoc.'</p>';

$destino1 = $_POST['destino1'];
//echo '<p>Destino:'.$destino1.'</p>';

$elaborador1 = $_POST['elaborador1'];
//echo '<p>Elaborador:'.$elaborador1.'</p>';

$assunto1 = $_POST['assunto1'];
//echo '<p>Assunto:'.$assunto1.'</p>';

$interessado1 = $_POST['interessado1'];
//echo '<p>Interessado:'.$interessado1.'</p>';

$referencia1 = $_POST['referencia1'];
//echo '<p>Referencia:'.$referencia1.'</p>';

$numero = $_POST['numero'];
//echo '<p>Numero:'.$numero.'</p>';

if ($iddoc == 1) {
$sqlat = "UPDATE NumCPR SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numcpr='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 2) {
$sqlat = "UPDATE NumCP SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numcp='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 3) {
$sqlat = "UPDATE NumCV SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numcv='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 4) {
$sqlat = "UPDATE NumDE SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numde='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 5) {
$sqlat = "UPDATE NumInf SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numinf='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 6) {
$sqlat = "UPDATE NumIT SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numit='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 7) {
$sqlat = "UPDATE NumIP SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numip='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 8) {
$sqlat = "UPDATE NumLD SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numld='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 9) {
$sqlat = "UPDATE NumMm SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numme='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 10) {
$sqlat = "UPDATE NumEM SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numem='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 11) {
$sqlat = "UPDATE NumFX SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numfx='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 12) {
$sqlat = "UPDATE NumNBI SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numnbi='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 13) {
$sqlat = "UPDATE NumOf SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numof='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 14) {
$sqlat = "UPDATE NumOS SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numos='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 15) {
$sqlat = "UPDATE NumPT SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numpt='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 16) {
$sqlat = "UPDATE NumPD SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numpd='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 17) {
$sqlat = "UPDATE NumRL SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numrl='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 18) {
$sqlat = "UPDATE NumAt SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numrl='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

if ($iddoc == 19) {
$sqlat = "UPDATE NumCt SET destino='$destino1',elaborador='$elaborador1',assunto='$assunto1',interessado='$interessado1',referencia='$referencia1' WHERE numrl='$numero'";
//echo '<p>SQLAT:'.$sqlat.'</p>';

$atualizar = mysql_query($sqlat, $conexao) or die ("mysql_query: ".mysql_error());
}

echo '<META http-equiv="refresh" content="2;url=/joomla25/sjd/numerador/numerador.php">';

?>