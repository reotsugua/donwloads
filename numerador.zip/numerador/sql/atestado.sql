--
-- Estrutura para tabela `NumAt`
--

CREATE TABLE IF NOT EXISTS `NumAt` (
  `numat` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(50) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(50) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numat`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `NumCt` (
  `numct` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(50) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(50) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numct`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;


