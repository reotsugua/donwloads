--
-- Estrutura da tabela `TipoDoc`
--

CREATE TABLE IF NOT EXISTS `TipoDoc` (
  `iddoc` int(11) NOT NULL AUTO_INCREMENT,
  `documento` varchar(50) NOT NULL,
  PRIMARY KEY (`iddoc`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Extraindo dados da tabela `TipoDoc`
--

INSERT INTO `TipoDoc` (`iddoc`, `documento`) VALUES
(1, 'CARTA PRECATORIA'),
(2, 'CERTIDAO DE PUBLICIDADE'),
(3, 'CONVITE'),
(4, 'DESPACHO'),
(5, 'INFORMACAO'),
(6, 'INTIMACAO'),
(7, 'INVESTIGACAO PRELIMINAR'),
(8, 'LAUDA'),
(9, 'MEMORANDO'),
(10, 'MENSAGEM DE EMAIL'),
(11, 'MENSAGEM DE FAX'),
(12, 'NOTA PARA BOLETIM INTERNO'),
(13, 'OFICIO'),
(14, 'ORDEM DE SERVICO'),
(15, 'PARTE'),
(16, 'PROCEDIMENTO DISCIPLINAR');

--
-- Estrutura da tabela `NumCPR` 01
--

CREATE TABLE IF NOT EXISTS `NumCPR` (
  `numcpr` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numcpr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `NumCP` 02
--

CREATE TABLE IF NOT EXISTS `NumCP` (
  `numcp` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numcp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `NumCV` 03
--

CREATE TABLE IF NOT EXISTS `NumCV` (
  `numcv` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numcv`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `NumDE` 04 
--

CREATE TABLE IF NOT EXISTS `NumDE` (
  `numde` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
   PRIMARY KEY (`numde`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `NumInf` 05
--

CREATE TABLE IF NOT EXISTS `NumInf` (
  `numinf` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
   PRIMARY KEY (`numinf`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `NumIT` 06
--

CREATE TABLE IF NOT EXISTS `NumIT` (
  `numit` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numit`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `NumIP` 07
--

CREATE TABLE IF NOT EXISTS `NumIP` (
  `numip` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
   PRIMARY KEY (`numip`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `NumLD` 08
--

CREATE TABLE IF NOT EXISTS `NumLD` (
  `numld` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numld`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `NumMm` 09
--

CREATE TABLE IF NOT EXISTS `NumMm` (
  `nummm` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`nummm`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `NumEM` 10
--

CREATE TABLE IF NOT EXISTS `NumEM` (
  `numem` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numem`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `NumFX` 11
--

CREATE TABLE IF NOT EXISTS `NumFX` (
  `numfx` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numfx`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `NumNBI` 12
--

CREATE TABLE IF NOT EXISTS `NumNBI` (
  `numnbi` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numnbi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;


--
-- Estrutura da tabela `NumOf` 13
--

CREATE TABLE IF NOT EXISTS `NumOf` (
  `numof` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numof`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `NumOS` 14
--

CREATE TABLE IF NOT EXISTS `NumOS` (
  `numos` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numos`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `NumPT` 15
--

CREATE TABLE IF NOT EXISTS `NumPT` (
  `numpt` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numpt`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `NumPD` 16
--

CREATE TABLE IF NOT EXISTS `NumPD` (
  `numpd` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numpd`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `NumRL` 17
--

CREATE TABLE IF NOT EXISTS `NumRL` (
  `numrl` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numrl`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;