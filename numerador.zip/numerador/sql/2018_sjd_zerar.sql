use SJD;
RENAME TABLE NumAt TO NumAt2018;
CREATE TABLE IF NOT EXISTS `NumAt` (
  `numat` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(50) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(50) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numat`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumBIA TO NumBIA2018;
CREATE TABLE IF NOT EXISTS `NumBIA` (
  `numbi` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(50) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `referencia` varchar(50) NOT NULL,
  PRIMARY KEY (`numbi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumCP TO NumCP2018;
CREATE TABLE IF NOT EXISTS `NumCP` (
  `numcp` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numcp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumCPA TO NumCPA2018;
CREATE TABLE IF NOT EXISTS `NumCPA` (
  `numcp` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(50) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `referencia` varchar(50) NOT NULL,
  PRIMARY KEY (`numcp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumCPR TO NumCPR2018;
CREATE TABLE IF NOT EXISTS `NumCPR` (
  `numcpr` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numcpr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumCt TO NumCt2018;
CREATE TABLE IF NOT EXISTS `NumCt` (
  `numct` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(50) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(50) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numct`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumCV TO NumCV2018;
CREATE TABLE IF NOT EXISTS `NumCV` (
  `numcv` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numcv`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumDE TO NumDE2018;
CREATE TABLE IF NOT EXISTS `NumDE` (
  `numde` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numde`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumDHA TO NumDHA2018;
CREATE TABLE IF NOT EXISTS `NumDHA` (
  `numdh` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(50) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `referencia` varchar(50) NOT NULL,
  PRIMARY KEY (`numdh`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumDpA TO NumDpA2018;
CREATE TABLE IF NOT EXISTS `NumDpA` (
  `numdp` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(50) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `referencia` varchar(50) NOT NULL,
  PRIMARY KEY (`numdp`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumEM TO NumEM2018;
CREATE TABLE IF NOT EXISTS `NumEM` (
  `numem` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numem`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumEmA TO NumEmA2018;
CREATE TABLE IF NOT EXISTS `NumEmA` (
  `numem` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(50) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `referencia` varchar(50) NOT NULL,
  PRIMARY KEY (`numem`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumFX TO NumFX2018;
CREATE TABLE IF NOT EXISTS `NumFX` (
  `numfx` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numfx`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumInf TO NumInf2018;
CREATE TABLE IF NOT EXISTS `NumInf` (
  `numinf` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numinf`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumIP TO NumIP2018;
CREATE TABLE IF NOT EXISTS `NumIP` (
  `numip` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numip`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumIT TO NumIT2018;
CREATE TABLE IF NOT EXISTS `NumIT` (
  `numit` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numit`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumLD TO NumLD2018;
CREATE TABLE IF NOT EXISTS `NumLD` (
  `numld` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numld`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumMm TO NumMm2018;
CREATE TABLE IF NOT EXISTS `NumMm` (
  `nummm` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`nummm`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumNBI TO NumNBI2018;
CREATE TABLE IF NOT EXISTS `NumNBI` (
  `numnbi` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numnbi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumOf TO NumOf2018;
CREATE TABLE IF NOT EXISTS `NumOf` (
  `numof` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numof`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumOS TO NumOS2018;
CREATE TABLE IF NOT EXISTS `NumOS` (
  `numos` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numos`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumOSA TO NumOSA2018;
CREATE TABLE IF NOT EXISTS `NumOSA` (
  `numos` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(50) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `referencia` varchar(50) NOT NULL,
  PRIMARY KEY (`numos`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumPD TO NumPD2018;
CREATE TABLE IF NOT EXISTS `NumPD` (
  `numpd` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numpd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumPT TO NumPT2018;
CREATE TABLE IF NOT EXISTS `NumPT` (
  `numpt` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numpt`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

RENAME TABLE NumRL TO NumRL2018;
CREATE TABLE IF NOT EXISTS `NumRL` (
  `numrl` int(11) NOT NULL AUTO_INCREMENT,
  `destino` varchar(100) NOT NULL,
  `elaborador` varchar(50) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `interessado` varchar(50) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `datasystem` datetime NOT NULL,
  PRIMARY KEY (`numrl`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;